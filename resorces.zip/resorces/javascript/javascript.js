// JavaScript Document
var a = 5;
var b = 10;
console.log(a+b);
console.log(a-b);
console.log(a/b);
console.log(a*b);
console.log(b%2);
console.log(a==b);


if(a <= 5) {
    console.log("Tallet er mindre");
} else if(a >= 5) {
    console.log("tallet er høgyere");
} 